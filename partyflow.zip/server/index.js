const express = require("express");
const http = require("http");
const cors = require("cors");
const { Server } = require("socket.io");

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

let events = {};

io.on("connection", (socket) => {
  socket.on("join-event", (eventId) => {
    socket.join(eventId);
  });

  socket.on("request-song", ({ eventId, song }) => {
    if (!events[eventId]) events[eventId] = { queue: [] };

    events[eventId].queue.push({
      id: Date.now().toString(),
      title: song,
      votes: 0
    });

    io.to(eventId).emit("queue-update", events[eventId].queue);
  });

  socket.on("vote-song", ({ eventId, songId, type }) => {
    const event = events[eventId];
    if (!event) return;

    const song = event.queue.find(s => s.id === songId);
    if (!song) return;

    if (type === "up") song.votes++;
    if (type === "down") song.votes--;

    event.queue.sort((a,b)=>b.votes-a.votes);

    io.to(eventId).emit("queue-update", event.queue);
  });
});

server.listen(4000, () => console.log("PartyFlow server running on 4000"));
