# PartyFlow (MVP)

## Setup

### Server
```
cd server
npm install
npm start
```

Runs on http://localhost:4000

### Frontend
Open:
- web/guest.html
- web/host.html

Make sure server is running first.
